
import './App.css';

import TodoList from './Components/list';

function App() {
  return (
    <div className="todo-app">

      <h1> My Todo App</h1>
      <TodoList />
    </div>
  );
}

export default App;
